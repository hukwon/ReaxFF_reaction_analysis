#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <cstdlib>
#include "atom.h"
#include "functions.h"

using namespace std;
//********************************************************************************************
void find_no_lines(int &nlines1,int &natoms1,int &nframes1){
     using namespace std;
     
     int i,j,k;
     int a;
     string line;
     string filename;
     ifstream myfile;
     istringstream instream;
     
     //cout << "Counting number of lines in file" << endl;
     
     nlines1 =0;
     myfile.open("reaction.in");
     if(myfile){
                while (getline(myfile, line))
                      {
                       nlines1 = nlines1 + 1;
                       }
                 }else{
                       cout << "file not found" << endl;
                       //system("Pause");
                       //exit(1);
                       }
     myfile.clear();
     myfile.seekg(0, ios::beg);
     myfile.close();
     
     //cout <<"Number of lines in file are " << nlines1 << endl;
     
    myfile.open ("reaction.in");
    getline (myfile,line);
    instream.clear();
    instream.str(line);
     if (instream >> a ) {
            instream >> ws;        // Skip white space, if any.
            if (instream.eof()) {  // true if we're at end of string.
                //cout << "OK." << endl;
            } else {
                cout << "BAD. Too much on the line." << endl;
                //system("Pause");
                //exit(1);
            }
        } else {
            cout << "BAD: Didn't find the three items." << endl;
            //system("Pause");
            //exit(1);
        }
    natoms1 = a;
    myfile.clear();
    myfile.seekg(0, ios::beg);
    myfile.close();
    
    
    nframes1 = nlines1/(natoms1 + 2);
    cout << "number of atoms are " << natoms1 <<endl;
    cout << "number of frames are " << nframes1 << endl;

}
//********end of find no of lines function ************************************************

//************begining of read input xmolout function**************************************
int read_input_xmolout(istream &myfile,int nframes1, int natoms1,atom **at_list1){                      
    int i,j,k;
    int a;
    double xc,yc,zc;
    double dx,dy,dz;
    double ax,ay,az,ang1,ang2,ang3;
    //string ans;
    string line,line1,at; 
    //ifstream myfile;
    istringstream instream;
    
          
    // read in the xmolout file
    //myfile.open("first.xyz");
    for (i=0;i<nframes1;i++){
    //i=0;
    getline (myfile,line);
    instream.clear();
    instream.str(line);
     if (instream >> a ) {
            instream >> ws;        // Skip white space, if any.
            if (instream.eof()) {  // true if we're at end of string.
                //cout << "OK." << endl;
            } else {
                cout << "BAD. Too much on the line." << endl;
                //system("Pause");
                //exit(1);
            }
        } else {
            //cout << "BAD: Didn't find the required number of items." << endl;
        }

    getline (myfile,line);
    instream.clear();
    instream.str(line);
    /*if (instream >> line1 ) {
            instream >> ws;        // Skip white space, if any.
        } else {
            cout << "BAD: Didn't find the required number of items at cell parameter lines" << endl;
            system("Pause");
            exit(1);
        }
    cell_parameter_lines1[i] = line1;
    
    find_cell_parameters(line,ax,ay,az,ang1,ang2,ang3);
    
    if(ans == "n"){
               lx1[i] = 80.0;
               ly1[i] = 80.0;
               lz1[i] = 80.0;
               
               alpha1[i] = 90.0;
               beta1[i]  = 90.0;
               gama1[i]  = 90.0;
           }else{
                     lx1[i] = ax;
                     ly1[i] = ay;
                     lz1[i] = az;
               
                     alpha1[i] = ang1;
                     beta1[i]  = ang2;
                     gama1[i]  = ang3;
                 }*/
    //cout << lx1[i] << " " << ly1[i] << " " << lz1[i] << endl;
    for (j=0;j<natoms1;j++){
                            getline (myfile,line);
                            instream.clear();
                            instream.str(line);
                            if (instream >> at >> xc >> yc >> zc) {
                                         instream >> ws;        // Skip white space, if any.
                                         } else {
                                                cout << "BAD: Didn't find the required number of items." << endl;
                                                //system("Pause");
                                                //exit(1);
                                                }
                            //cout << xc <<" "<< yc <<" "<< zc <<" " << at << endl;
                            at_list1[i][j].set_coordinates(xc,yc,zc,at);   
        }
        }
    //cout << at_list1[0][natoms1-1].return_xcord()<<endl;
    
    //myfile.close();

     }
//*****************end of read input xmolout function*************************************

//***********begining of find cell parameters function************************************
void find_cell_parameters(string s1, double &xx, double &yy, double &zz, double &ang1, double &ang2, double &ang3){
     int i,j,k;
     int count;
     string temp1;
     string sub;
     string *temp_strs;
     istringstream iss(s1);
     istringstream iss1(s1);
     
     //cout << s1 << endl;
     count= 0;
     
     while(iss >> sub){
               count = count + 1;
               }
     //cout << "Count is " << count << endl;
     
     temp_strs = new string[count];
     
     i=0;
     while (iss1 >> sub){
           temp_strs[i] = sub;
           //cout << temp_strs[i] << endl;
           i= i +1;
           }
     
     ang3 = atof(temp_strs[count-1].c_str());
     ang2 = atof(temp_strs[count-2].c_str());
     ang1 = atof(temp_strs[count-3].c_str());
     
     zz = atof(temp_strs[count-4].c_str());
     yy = atof(temp_strs[count-5].c_str());
     xx = atof(temp_strs[count-6].c_str());
     
     //cout << ang1 << " " << ang2 << " " << ang3 << " " << endl;
     
     delete[] temp_strs;
     }
//**********end of find cell parameters function******************************************

