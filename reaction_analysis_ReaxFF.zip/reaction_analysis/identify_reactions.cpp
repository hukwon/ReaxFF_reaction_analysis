#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include "atom.h"
#include "functions.h"

using namespace std;

void identify_reactions(int frame,int size1,atom **at_list1,int *reactive_atoms1){
     
     int i,j,k;
     int n1,n2,n3,n4;
     int m1,m2,m3;
     int reactions;
     int temp_atoms[100000];
     int temp_size;
     int temp1,temp2;
     string s1,s2,s3;
     string flag,flag1;
     string reactants[50];
     string products[50];
     int molecule_flags[2][10000];
     int rcount,pcount;
     int num_reactions;
     int max_reactions = 100;
     
     ofstream myfile1,myfile2,myfile3;
     
     flag = "Y";
     reactions = 0;
     
     myfile1.open("reactions.out",ios::app);
     //cout << "starting reaction analysis " << endl;
     myfile1 << "Printing reactions for frame " << frame << endl;
     cout << "Printing reactions for frame " << frame << endl;
     
     myfile2.open("reactants_products.dat",ios :: app);
     myfile2 << "Frame " << frame << endl;
     
     for(i=0;i<size1;i++){
                          n1 = reactive_atoms1[i];
                          at_list1[frame][n1].set_atom_state("N");
                          at_list1[frame-1][n1].set_atom_state("N");
                          }
     for (j=0;j<2;j++){
                       for (i=0;i<10000;i++){
                           molecule_flags[j][i] = 0; //0 means does not have reaction number, 1 means have reaction number
                           }
                       }
     
     while (flag=="Y"){
           n2 = 0;
           temp_size = 0;
           for(i=0;i<size1;i++){
                                n1 = reactive_atoms1[i];
                                if ( at_list1[frame][n1].return_atom_state() == "Y"){
                                     n2 = n2 + 1;
                                   }else{
                                         temp_atoms[temp_size] = n1;
                                         //add temp-size check to avoid segmentation fault
                                         temp_size = temp_size + 1;
                                         }
                                }
           if(n2 == size1){
                 flag = "N";
                 //break;
                 }else{
                      /*for (j=0;j<2;j++){
                        for (i=0;i<10000;i++){
                            molecule_flags[j][i] = 0; //0 means does not have reaction number, 1 means have reaction number
                            }
                       }*/
                       //found new reaction.
                       //begin search of that new reaction
                       rcount = 0;
                       pcount = 0;
                       n1 = temp_atoms[0];
                       at_list1[frame][n1].set_atom_state("Y");
                       at_list1[frame-1][n1].set_atom_state("Y");
                                                                                       
                       n4 = at_list1[frame][n1].return_mol_no() - 1;
                       if(molecule_flags[1][n4] == 0){
                                                products[pcount] = at_list1[frame][n1].return_mol_name();
                                                pcount = pcount + 1;
                                                molecule_flags[1][n4] = 1;
                                                }
                       //update all the remaining product atoms that are part of this molecule
                       for(k=0;k<temp_size;k++){
                                                 n3 = temp_atoms[k];
                                                 s1 = at_list1[frame][n3].return_atom_state();
                                                 m1 = at_list1[frame][n3].return_mol_no() - 1;
                                                                                                
                                                 if(s1 == "N" && m1 == n4){
                                                       at_list1[frame][n3].set_atom_state("Y");
                                                       at_list1[frame-1][n3].set_atom_state("Y");
                                                       }
                                                 }
                                                                                       
                       n4 = at_list1[frame-1][n1].return_mol_no() - 1;
                       if(molecule_flags[0][n4] == 0){
                                                reactants[rcount] = at_list1[frame-1][n1].return_mol_name();
                                                rcount = rcount + 1;
                                                molecule_flags[0][n4] = 1;
                                                }
                       //update all the remaining reactant atoms that are part of this molecule
                       for(k=0;k<temp_size;k++){
                                                 n3 = temp_atoms[k];
                                                 s1 = at_list1[frame-1][n3].return_atom_state();
                                                 m1 = at_list1[frame-1][n3].return_mol_no() - 1;
                                                                                                
                                                 if(s1 == "N" && m1 == n4){
                                                       at_list1[frame][n3].set_atom_state("Y");
                                                       at_list1[frame-1][n3].set_atom_state("Y");
                                                       }
                                                 }
                                            
                                                                                //}
                       //finished opening cycle
                                                                  
                       //2nd cycle begins here
                       flag1 = "Y";
                       //temp1 = 0;
                       //temp2 = 0;
                       while(flag1 == "Y"){
                                   temp1 = 0;
                                   temp2 = 0;
                                   //begin with product side
                                   for(k=0;k<temp_size;k++){
                                                            m1 = temp_atoms[k];
                                                            s1 = at_list1[frame][m1].return_atom_state();
                                                            n4 = at_list1[frame][m1].return_mol_no() - 1;
                                                                                           
                                                            if(s1 == "Y" && molecule_flags[1][n4] == 0){
                                                                  products[pcount] = at_list1[frame][m1].return_mol_name();
                                                                  pcount = pcount + 1;
                                                                  molecule_flags[1][n4] = 1;
                                                                  //assign "Y" status to remaining atoms of the molecule 
                                                                  for (j=0;j<temp_size;j++){
                                                                      m2 = temp_atoms[j];
                                                                      s2 = at_list1[frame][m2].return_atom_state();
                                                                      n3 = at_list1[frame][m2].return_mol_no()-1;
                                                                                               
                                                                      if(s2 == "N" && n3 == n4){
                                                                            at_list1[frame][m2].set_atom_state("Y");
                                                                            at_list1[frame-1][m2].set_atom_state("Y");
                                                                      }
                                                                  }
                                                            }else{
                                                                  temp1 = temp1 + 1;
                                                                  }
                                                                                                 
                                                            }
                                   //now begin reactant side
                                   for(k=0;k<temp_size;k++){
                                                            m1 = temp_atoms[k];
                                                            s1 = at_list1[frame-1][m1].return_atom_state();
                                                            n4 = at_list1[frame-1][m1].return_mol_no() - 1;
                                                                                           
                                                            if(s1 == "Y" && molecule_flags[0][n4] == 0){
                                                                  reactants[rcount] = at_list1[frame-1][m1].return_mol_name();
                                                                  rcount = rcount + 1;
                                                                  molecule_flags[0][n4] = 1;
                                                      
                                                                  //assign "Y" status to remaining atoms of the molecule 
                                                                  for (j=0;j<temp_size;j++){
                                                                      m2 = temp_atoms[j];
                                                                      s2 = at_list1[frame-1][m2].return_atom_state();
                                                                      n3 = at_list1[frame-1][m2].return_mol_no()-1;
                                                                                               
                                                                      if(s2 == "N" && n3 == n2){
                                                                            at_list1[frame][m2].set_atom_state("Y");
                                                                            at_list1[frame-1][m2].set_atom_state("Y");
                                                                      }
                                                                  }
                                                            }else{
                                                                  temp2= temp2 + 1;
                                                                  }
                                                                                                 
                                   }
                       if(temp1 == temp_size && temp2 == temp_size){
                       //if(temp1 == temp_size ){
                                flag1 = "N";
                                }
                       } ///2nd while loop ends here
                       
                       /*//3rd cycle begins here
                       //begin with product side
                       for(k=0;k<temp_size;k++){
                                                m1 = temp_atoms[k];
                                                s1 = at_list1[frame][m1].return_atom_state();
                                                n2 = at_list1[frame][m1].return_mol_no() - 1;
                                                                                           
                                                if(s1 == "Y" && molecule_flags[1][n2] == 0){
                                                      products[pcount] = at_list1[frame][m1].return_mol_name();
                                                      pcount = pcount + 1;
                                                      molecule_flags[1][n2] = 1;
                                                      
                                                      //assign "Y" status to remaining atoms of the molecule 
                                                      for (j=0;j<temp_size;j++){
                                                          m2 = temp_atoms[j];
                                                          s2 = at_list1[frame][m2].return_atom_state();
                                                          n3 = at_list1[frame][m2].return_mol_no()-1;
                                                                                               
                                                          if(s2 == "N" && n3 == n2){
                                                                at_list1[frame][m2].set_atom_state("Y");
                                                                at_list1[frame-1][m2].set_atom_state("Y");
                                                                }
                                                          }
                                                      }
                                                                                                 
                                                }
                       //now begin reactant side
                       for(k=0;k<temp_size;k++){
                                                m1 = temp_atoms[k];
                                                s1 = at_list1[frame-1][m1].return_atom_state();
                                                n2 = at_list1[frame-1][m1].return_mol_no() - 1;
                                                                                           
                                                if(s1 == "Y" && molecule_flags[0][n2] == 0){
                                                      reactants[rcount] = at_list1[frame-1][m1].return_mol_name();
                                                      rcount = rcount + 1;
                                                      molecule_flags[0][n2] = 1;
                                                      //assign "Y" status to remaining atoms of the molecule 
                                                      for (j=0;j<temp_size;j++){
                                                          m2 = temp_atoms[j];
                                                          s2 = at_list1[frame-1][m2].return_atom_state();
                                                          n3 = at_list1[frame-1][m2].return_mol_no()-1;
                                                                                               
                                                          if(s2 == "N" && n3 == n2){
                                                                at_list1[frame][m2].set_atom_state("Y");
                                                                at_list1[frame-1][m2].set_atom_state("Y");
                                                                }
                                                          }
                                                      }
                                                                                                 
                                                }                                                                   
                       //4th cycle begins here
                       //begin with product side
                       for(k=0;k<temp_size;k++){
                                                m1 = temp_atoms[k];
                                                s1 = at_list1[frame][m1].return_atom_state();
                                                n2 = at_list1[frame][m1].return_mol_no() - 1;
                                                                                           
                                                if(s1 == "Y" && molecule_flags[1][n2] == 0){
                                                      products[pcount] = at_list1[frame][m1].return_mol_name();
                                                      pcount = pcount + 1;
                                                      molecule_flags[1][n2] = 1;
                                                      
                                                      //assign "Y" status to remaining atoms of the molecule 
                                                      for (j=0;j<temp_size;j++){
                                                          m2 = temp_atoms[j];
                                                          s2 = at_list1[frame][m2].return_atom_state();
                                                          n3 = at_list1[frame][m2].return_mol_no()-1;
                                                                                               
                                                          if(s2 == "N" && n3 == n2){
                                                                at_list1[frame][m2].set_atom_state("Y");
                                                                at_list1[frame-1][m2].set_atom_state("Y");
                                                                }
                                                          }
                                                      }
                                                                                                 
                                                }
                       //now begin reactant side
                       for(k=0;k<temp_size;k++){
                                                m1 = temp_atoms[k];
                                                s1 = at_list1[frame-1][m1].return_atom_state();
                                                n2 = at_list1[frame-1][m1].return_mol_no() - 1;
                                                                                           
                                                if(s1 == "Y" && molecule_flags[0][n2] == 0){
                                                      reactants[rcount] = at_list1[frame-1][m1].return_mol_name();
                                                      rcount = rcount + 1;
                                                      molecule_flags[0][n2] = 1;
                                                      //assign "Y" status to remaining atoms of the molecule 
                                                      for (j=0;j<temp_size;j++){
                                                          m2 = temp_atoms[j];
                                                          s2 = at_list1[frame-1][m2].return_atom_state();
                                                          n3 = at_list1[frame-1][m2].return_mol_no()-1;
                                                                                               
                                                          if(s2 == "N" && n3 == n2){
                                                                at_list1[frame][m2].set_atom_state("Y");
                                                                at_list1[frame-1][m2].set_atom_state("Y");
                                                                }
                                                          }
                                                      }
                                                                                                 
                                                }     
                       //5th cycle begins here
                       //begin with product side
                       for(k=0;k<temp_size;k++){
                                                m1 = temp_atoms[k];
                                                s1 = at_list1[frame][m1].return_atom_state();
                                                n2 = at_list1[frame][m1].return_mol_no() - 1;
                                                                                           
                                                if(s1 == "Y" && molecule_flags[1][n2] == 0){
                                                      products[pcount] = at_list1[frame][m1].return_mol_name();
                                                      pcount = pcount + 1;
                                                      molecule_flags[1][n2] = 1;
                                                      
                                                      //assign "Y" status to remaining atoms of the molecule 
                                                      for (j=0;j<temp_size;j++){
                                                          m2 = temp_atoms[j];
                                                          s2 = at_list1[frame][m2].return_atom_state();
                                                          n3 = at_list1[frame][m2].return_mol_no()-1;
                                                                                               
                                                          if(s2 == "N" && n3 == n2){
                                                                at_list1[frame][m2].set_atom_state("Y");
                                                                at_list1[frame-1][m2].set_atom_state("Y");
                                                                }
                                                          }
                                                      }
                                                                                                 
                                                }
                       //now begin reactant side
                       for(k=0;k<temp_size;k++){
                                                m1 = temp_atoms[k];
                                                s1 = at_list1[frame-1][m1].return_atom_state();
                                                n2 = at_list1[frame-1][m1].return_mol_no() - 1;
                                                                                           
                                                if(s1 == "Y" && molecule_flags[0][n2] == 0){
                                                      reactants[rcount] = at_list1[frame-1][m1].return_mol_name();
                                                      rcount = rcount + 1;
                                                      molecule_flags[0][n2] = 1;
                                                      //assign "Y" status to remaining atoms of the molecule 
                                                      for (j=0;j<temp_size;j++){
                                                          m2 = temp_atoms[j];
                                                          s2 = at_list1[frame-1][m2].return_atom_state();
                                                          n3 = at_list1[frame-1][m2].return_mol_no()-1;
                                                                                               
                                                          if(s2 == "N" && n3 == n2){
                                                                at_list1[frame][m2].set_atom_state("Y");
                                                                at_list1[frame-1][m2].set_atom_state("Y");
                                                                }
                                                          }
                                                      }
                                                                                                 
                                                }    */
                       myfile2 << "New Reaction" << endl;                                                                                                                             
                       myfile2 << rcount << " " << pcount << endl;
                       for(i=0;i<rcount;i++){
                                             if(i!=0){
                                                      //cout << "+ ";
                                                      myfile1 << "+ ";
                                                      }
                                             //cout << reactants[i] << " ";
                                             myfile1 << reactants[i] << " " ;
                                             myfile2 << reactants[i] << endl;
                                             } 
                       //cout << "--------->" << "  " ;                      
                       myfile1 << "------->" << "  ";
                       for(i=0;i<pcount;i++){
                                             if(i!=0){
                                                      //cout << "+ ";
                                                      myfile1 << "+ " ;
                                                      }
                                             //cout << products[i] << " ";
                                             myfile1 << products[i] << " " ;
                                             myfile2 << products[i] << endl;
                                             }
                       //cout << endl;
                       myfile1 << endl;
                       
                       //analyze_reactions(int rcount, int pcount, int *reactants, int *products);
                       }//if else of new reaction
           }//while loop
     myfile1 << "--------------------------------------------------------------------------" << endl;
     
     myfile1.close();
     myfile2.close();
     
     cout << "Frame " << frame << "  finished " << endl;
     cout << "---------------------------------------------" << endl;
}
