#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include "atom.h"
#include "functions.h"

using namespace std;

void read_input_file(istream &myfile, int natoms1, int nframes1,atom **at_list1, int **num_neighbors1){
     int i,j,k;
     int n1,n2,n3,n4;
     int count1;
     string s1,s2,s3;
     string sub;
     istringstream iss;
     string temp[50];
     
     //read two consecutive frames
     for (i=0;i<nframes1;i++){
         s1.clear();
         getline(myfile,s1);
         n1 = atoi(s1.c_str());
         //cout << "no of atoms " << n1 << endl;
         getline(myfile,s2);
         
         for(j=0;j<n1;j++){
                           s1.clear();
                           getline(myfile,s1);
                           iss.clear();
                           iss.str(s1);
                           count1 =0;
                           while(iss >> sub){
                                     temp[count1] = sub;
                                     count1 = count1 + 1;
                                     }
                           //n2 = atoi(temp[1].c_str());
                           num_neighbors1[i][j] = atoi(temp[2].c_str());
                           n2 = atoi(temp[3].c_str());
                           at_list1[i][j].set_mol_no(n2);
                           at_list1[i][j].set_mol_name(temp[4]);
                           
                           }
     }
     
     }
