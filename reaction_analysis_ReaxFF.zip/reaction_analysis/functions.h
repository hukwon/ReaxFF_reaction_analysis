#include "atom.h"
#include "molecule.h"
#include<iostream>
#include<sstream>
#include<fstream>

using namespace std;

#ifndef FIND_NO_LINES_H
#define FIND_NO_LINES_H

void find_no_lines(int &nlines1, int &natoms1, int &nframes1);

#endif

#ifndef READ_INPUT_XMOLOUT_H
#define READ_INPUT_XMOLOUT_H

int read_input_xmolout(istream &myfile,int nframes1, int natoms1,atom **at_list1);                        

#endif

#ifndef FIND_CELL_PARAMETERS_H
#define FIND_CELL_PARAMETERS_H

void find_cell_parameters(string s1, double &xx, double &yy, double &zz, double &ang1, double &ang2, double &ang3);

#endif

#ifndef STRING_TO_INTEGER_H
#define STRING_TO_INTEGER_H

int string_to_integer(char *s1);

#endif

#ifndef STRING_TO_DOUBLE_H
#define STRING_TO_DOUBLE_H

double string_to_double(char *s1);

#endif

#ifndef FLOAT_TO_STRING_H
#define FLOAT_TO_STRING_H

string float_to_string(int a);

#endif

#ifndef IDENTIFY_ATOM_TYPES_H
#define IDENTIFY_ATOM_TYPES_H

void identify_atom_types(string *line1, int start_line_per_section[], int num_atom_types, string *atom_types1);

#endif

#ifndef READ_INPUT_FILE_H
#define READ_INPUT_FILE_H

void read_input_file(istream &myfile, int natoms1, int nframes1, atom **at_list1, int **num_neighbors1);

#endif

#ifndef IDENTIFY_REACTIVE_ATOMS_H
#define IDENTIFY_REACTIVE_ATOMS_H

void identify_reactive_atoms(int frame,int natoms1, int **num_neighbors1, int &size1,int *reactive_atoms1, atom **at_list1);

#endif

#ifndef IDENTIFY_REACTIONS_H
#define IDENTIFY_REACTIONS_H

void identify_reactions(int frame,int size1,atom **at_list1,int *reactive_atoms1);

#endif
