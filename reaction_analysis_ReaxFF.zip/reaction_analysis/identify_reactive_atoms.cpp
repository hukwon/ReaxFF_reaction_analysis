#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include "atom.h"
#include "functions.h"

using namespace std;

void identify_reactive_atoms(int frame,int natoms1, int **num_neighbors1, int& size1, int *reactive_atoms1, atom **at_list1){
     int i,j,k;
     int n1,n2,n3;
     string s1,s2,s3;
     ofstream myfile1,myfile2,myfile3;
     size1 = 0;
     
     
     for(i=0;i<natoms1;i++){
                            at_list1[frame][i].set_atom_state("N");
                            }
     
     for (i=0;i<natoms1;i++){
         if(at_list1[frame][i].return_atom_state() == "N"){
         s2 = at_list1[frame][i].return_mol_name();
         s3 = at_list1[frame-1][i].return_mol_name();
         if(num_neighbors1[frame][i] != num_neighbors1[frame-1][i] || s2 != s3){
                                     cout << i << endl;
                                     reactive_atoms1[size1] = i;
                                     size1 = size1 + 1;
                                     at_list1[frame][i].set_atom_state("Y");
                                     //find out the molecule number of the atom in the product state
                                     n1 = at_list1[frame][i].return_mol_no() - 1;
                                     //search for the atoms that are the component of this molecule
                                     for(k=0;k<natoms1;k++){
                                                            n2 = at_list1[frame][k].return_mol_no() - 1;
                                                            s1 = at_list1[frame][k].return_atom_state();
                                                            if(n2 == n1 && s1 == "N"){
                                                                  at_list1[frame][k].set_atom_state("Y");
                                                                  reactive_atoms1[size1] = k;
                                                                  size1 = size1 + 1;
                                                                  }
                                                            }
                                     }
         }
     }
     
    myfile3.open("reactive_atoms.dat",ios::app);
     myfile3 << size1 << endl;
     for(i=0;i<size1;i++){
                          //cout << reactive_atoms1[i] << " " << at_list1[frame][reactive_atoms1[i]].return_mol_name() << endl;
                          myfile3 << reactive_atoms1[i] << " " << at_list1[frame][reactive_atoms1[i]].return_mol_name()<< endl;
                          }
     myfile3.close();
     cout << size1 << endl;
     
     myfile1.open("reactant.xyz",ios::app);
     myfile2.open("product.xyz",ios::app);
     myfile1 << size1<< endl;
     myfile1 << " " << endl;
     
     myfile2 << size1 << endl;
     myfile2 << " " << endl; 
     for(i=0;i<natoms1;i++){
        if(at_list1[frame][i].return_atom_state() == "Y"){
                                                  myfile1 << at_list1[frame-1][i].return_atomname() << " " << at_list1[frame-1][i].return_xcord()
                                                  << " " << at_list1[frame-1][i].return_ycord() << " " <<at_list1[frame-1][i].return_zcord() << endl;
                                                  
                                                  myfile2 << at_list1[frame][i].return_atomname() << " " << at_list1[frame][i].return_xcord()
                                                  << " " << at_list1[frame][i].return_ycord() << " " <<at_list1[frame][i].return_zcord() << endl;
                                                  }                    
        }
     
     myfile1.close();
     myfile2.close();
     cout << "Finished identifying reactive atoms " << endl;
}
