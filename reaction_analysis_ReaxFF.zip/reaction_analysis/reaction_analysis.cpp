#include <cstdlib>
#include <iostream>
#include <fstream>
#include "atom.h"
#include "functions.h"

using namespace std;

int main(int argc, char *argv[])
{
    int i,j,k;
    int n1,n2,n3;
    int natoms,nframes,nlines;
    int frames1,max_neighbors;
    int *reactive_atoms;
    int size;
    string s1,s2;
    
    atom **at_list;
    int **num_neighbors;
    
    ifstream myfile1;
    ofstream myfile2;
    
    find_no_lines(nlines,natoms,nframes);
    
    // allocate memory for atoms
    frames1 =nframes;
    at_list = new atom *[frames1];
    if (at_list == NULL){
                cout <<"could not allocate memory \n";
                return 1;
                }
    for (i=0;i<frames1;i++){
        at_list[i] = new atom[natoms];
    }
    
    max_neighbors = 15;
    num_neighbors = new int *[frames1];
    if (num_neighbors == NULL){
                cout <<"could not allocate memory \n";
                return 1;
                }
    for (i=0;i<frames1;i++){
        num_neighbors[i] = new int[natoms];
    }
    
    reactive_atoms = new int [natoms];
    
    myfile1.open("reaction.in");
    //for (i=0;i<nframes-1;i++){
    //for(i=0;i<1;i++){
    //cout << "For frames " << i+1 << " and " << i+2 << endl;
    read_input_file(myfile1,natoms,nframes,at_list,num_neighbors);
    //}
    myfile1.close();
    
    myfile1.open("first.xyz");
    read_input_xmolout(myfile1,nframes, natoms,at_list);                      
    myfile1.close();
    
    myfile2.open("reactions.out");
    myfile2 << "Writing reactions" << endl;
    myfile2.close();
    
    myfile2.open("reactant.xyz");
    myfile2.close();
    
    myfile2.open("product.xyz");
    myfile2.close();
    
    myfile2.open("reactants_products.dat");
    myfile2.close();
    
    myfile2.open("reactive_atoms.dat");
    myfile2.close();
    
    //start the reaction search*************************
    for(i=1;i<nframes;i++){
    //for (i=1;i<4;i++){
                           //find reactive atoms
                           identify_reactive_atoms(i,natoms, num_neighbors, size,reactive_atoms,at_list);
                           /*for(j=0;j<size;j++){
                                               n1 = reactive_atoms[j];
                                               cout << reactive_atoms[j] << "  " << at_list[i][n1].return_mol_name() << endl;
                                               }*/
                           if(size != 0){
                                   identify_reactions(i,size,at_list,reactive_atoms);
                                   }
                           }
    //end of reaction search ***************************
    //deallocate atom_list and num_neighbor list
    for(i=0;i<frames1;i++){
                           delete [] at_list[i];
                           at_list[i] = NULL;
                           delete [] num_neighbors[i];
                           num_neighbors[i] = NULL;
                           }
    delete[] at_list;
    delete[] num_neighbors;
    delete[] reactive_atoms;
    system("Pause");
    
}
