#include<string>
#include "atom.h"

atom::atom(double xx, double yy, double zz, string at_name){
                    x =xx;
                    y =yy;
                    z =zz;
                    name = at_name;
                    mass = 0.0;
                    }
                    
/*void atom::set_coordinates(double xx, double yy, double zz, string at_name, int n1){
                     x = xx;
                     y = yy;
                     z = zz;
                     name = at_name;
                     mol_no = n1;
                     }*/
 
void atom::set_coordinates(double xx, double yy, double zz, string name1){
                     x = xx;
                     y = yy;
                     z = zz;
                     name = name1;
                     }
 
void atom::set_atom_characteristics(double xx, double yy, double zz, string at_name, int n1){
                     x = xx;
                     y = yy;
                     z = zz;
                     n1 = mol_no;
                     name = at_name;
                     }
                     
void atom::set_atom_state(string s1){
                     atom_state = s1;
                     }

void atom::set_mol_no(int i1){
                     mol_no = i1;
                     }

void atom::set_mol_name(string s1){
                     mol_name = s1;
                     }
