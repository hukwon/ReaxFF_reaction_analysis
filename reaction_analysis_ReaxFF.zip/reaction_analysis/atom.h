#ifndef ATOM_H
#define ATOM_H
#include <string>

using std::string;
class atom{
      protected:
              double x,y,z;
              double mass;
              int mol_no;
              int flag1;
              string name;
              string mol_name;
              string atom_state;
      public:
             atom(){
                    x = 0.0;
                    y = 0.0;
                    z = 0.0;
                    mass = 0.0;
                    mol_no = 0;
                    name = "No";
                    }
         atom(double xx, double yy, double zz, string at_name);
         double return_xcord(){ return x;}
         double return_ycord(){return y;}
         double return_zcord() {return z;}
         string return_atomname() { return name;}
         string return_atom_state() { return atom_state;}
         string return_mol_name() {return mol_name;}
         int return_mol_no(){ return mol_no;}
         
         void set_coordinates(double xx, double yy, double zz, string at_name, int n1);
         void set_coordinates(double xx, double yy, double zz, string name1);
         void set_atom_characteristics(double xx, double yy, double zz, string at_name, int n1);
         void set_atom_state(string s1);
         void set_mol_no(int i1);
         void set_mol_name(string s1);
      };
      
#endif
