This code will identify reactions between two consecutive frames. This code
has been tested so far only for gas phase systems.

Input files : reaction.in 
              first.xyz (same number of frames as reaction.in)

output files : reactions.out
               reactant.xyz and product.xyz (coordinates of only those atoms which
               participated in the reactive events)

