#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <stdlib.h>
#include <math.h>
#include <vector>
#include <algorithm>
#include "atom.h"
#include "voids.h"
#include "functions.h"

using namespace std;
const int max_neigh_size = 5000;
void identify_void_edges(int no_voids,voids *void_list1, emptyBin *bin_list1,int ***grid_atom_count1);
void find_void_surface_atoms(int no_voids, int natoms, double grid_dr1,voids *void_list1, emptyBin *bin_list1, int ***grid_atom_count1, int ****grid_list1, atom **at_list1, double **lx1, double **ly1, double **lz1, int nx1, int ny1, int nz1);
bool sortcol( const vector<double>& v1,const vector<double>& v2);
void surface_atoms(int dirn,double grid_dr1, double xc, double yc, double zc,atom **at_list1, voids *void_list1,double **lx1, double **ly1, double **lz1);

void identify_voids(int act_frame, int natoms1, double grid_dr1,int no_empty_bins, emptyBin *bin_list1,int ***grid_atom_count1,int ****grid_list1, atom **at_list1, double **lx1, double **ly1, double **lz1, int nx1, int ny1, int nz1){
     cout << "starting void identification " << endl;
     int i,j,k;
     int l,m,n;
     int count1,count2,tmp_no,no_cycles;
     int no1,no2,no3,no4;
     int no_types_voids[max_void_types];         
     double void_vols[max_void_types];
     int pop_voids[max_void_types];
     int no_voids;
     //int temp_neighbours[natoms1];  //20 is assumed as maximum no of neighbours
     int temp_neighbors,temp_bins,temp_vol;
     int first_neighbours[max_neigh_size];
     int second_neighbours[max_neigh_size];
     string sub,des;
     string flag;
     string s1,s2;
     string lines;
     string temp_lines[50];
     int flags[no_empty_bins]; //0 means yes, 1 means NO
     cout << "starting molecule identification " << endl;
     voids *void_list;
     vector < vector < int > > void_bin_list;
     vector < int > temp_void_bins;
     ifstream myfile;
     ofstream myfile1,myfile2;
     istringstream iss;
     
     //initialize the void status of every bin to No
     for(j=0;j<no_empty_bins;j++){
        bin_list1[j].set_bin_state(1);
     }
     
     //cout << "finished setting atom state" << endl;
     //myfile.open("temp_connection_table.txt");
     
     no_voids = 0;
     
     //identify isolated voids, meaning bins with 0 empty neighbors. Isolated empty bins will not be considered as voids 
     for(j=0;j<no_empty_bins;j++){
         if(bin_list1[j].num_neighbors == 0){
            bin_list1[j].set_bin_state(0);
            //no_voids = no_voids + 1;
            bin_list1[j].set_void_no(-1);
         }
     }
     //start looking for bins of every void
     cout << "Number of unimolecular pieces are " << no_voids << endl;
     for(j=0;j<no_empty_bins;j++){
         temp_neighbors = bin_list1[j].num_neighbors;
         if(bin_list1[j].return_bin_state() == 1 && temp_neighbors != 0){
            no_voids = no_voids + 1;
            //identify first immediate neighbours
            no1= temp_neighbors;
            //cout << "No of neighbours are " << no1 << endl;
            //count1 = 0;
            for(k=0;k<no1;k++){
                first_neighbours[k] = bin_list1[j].neigh_indexes[k]-1;
                //cout << "First neighbors " << first_neighbours[k] << endl;
            }
                                                                                         
            flag = "Yes";
            no_cycles = 0;
            while(flag == "Yes"){
                  for(k=0;k<no_empty_bins;k++){
                      flags[k] = 1;
                  }
                  count2 = 0;
                  count1 = 0;
                  //cout << "for cycle " << no_cycles + 1 << " count1 no is " << count1 << endl;
                  //cout << no_cycles+1 << " started " << endl;
                  for(k=0;k<no1;k++){
                      no2= first_neighbours[k];
                      if(bin_list1[no2].return_bin_state() == 1){
                         bin_list1[no2].set_void_no(no_voids);
                         bin_list1[no2].set_bin_state(0);
                      }else{
                         count2 = count2 + 1;
                      }
                                                                                                            
                      no3 = bin_list1[no2].num_neighbors; //temp_neighbours[no2];
                      //cout << "k with no2 " << k << " with no2 equal to " << no2 << endl;
                                                                                                            
                      for(l=0;l<no3;l++){
                          no4 = bin_list1[no2].neigh_indexes[l]-1; //neighbours_index[no2][l] - 1;
                          if(bin_list1[no4].return_bin_state() == 1 && flags[no4] == 1){
                             second_neighbours[count1] = bin_list1[no2].neigh_indexes[l]-1; //neighbours_index[no2][l] - 1;
                             flags[no4] = 0;
                             count1 = count1 + 1;
                          }
                       }
                       //cout << "k is " << k << "  no2 is " << no2 << "  no4 is " << no4 << endl;
                       //cout << at_list1[i][no2].return_atomname() << " " << no2 << " done" << endl;
                       //cout << count1 << endl;
                  }
                  //cout << no_cycles + 1 << " reached until here " << endl;
                  //cout << count1 << endl;
                  if (count1 > max_neigh_size ){
                      cout << "Increase size of second_neighbour array" << endl;
                      //system("Pause");
                      exit(1);
                  }
                  if(count2 == no1){
                     flag = "No";
                     //break;
                  }else{//transfer second neighbour into the first neighbour
                     flag = "Yes";
                     no1 = count1;
                     for(k=0;k<no1;k++){
                         first_neighbours[k] = second_neighbours[k];
                     }
                  }
                  no_cycles = no_cycles + 1;
                  //cout << "Cycle number is " << no_cycles << " with count1 number "<< count1 << endl;
            }
                                                    
            //cout << "atom " << j << " is done " << endl;
         }//end of if 
     }//end of natoms1 for loop
                             
     cout << "No voids in frame " << act_frame << " is " << no_voids << endl;
     
     //myfile.close();
     
     //allocate array for voids
     void_list = new voids [no_voids];

     //identify size of each void
     for (i=0;i<no_voids;i++){
          temp_bins = 0;
          temp_vol  = 0.0;
          temp_void_bins.clear();
          for (j=0;j<no_empty_bins;j++){
               if (bin_list1[j].return_void_no() == i+1){
                   temp_bins = temp_bins + 1;
                   temp_vol = temp_vol + bin_list1[j].return_bin_vol();
                   void_list[i].vbin_list.push_back(j);
                   //void_list[i].add_bin(j);
                   temp_void_bins.push_back(j);
               }
          }
          void_list[i].set_void_no_bins(temp_bins);
          void_list[i].set_void_vol(temp_vol);
          void_bin_list.push_back(temp_void_bins);
     }
     
     //void population analysis
     for(i=0;i<max_void_types;i++){
         pop_voids[i]=0;
     }

     count1=0;
     for(i=0;i<no_voids;i++){
         s2= "N";
         if(i==0){
            void_vols[count1] = void_list[i].return_void_vol();
            no_types_voids[count1]= void_list[i].return_no_bins();
            pop_voids[count1] = pop_voids[count1] + 1;
            count1 = count1 + 1;
            s2 = "Y";
          }else{
           //temp_bins = void_list[i].return_no_bins();
           temp_vol = void_list[i].return_void_vol();
           for(j=0;j<count1;j++){
               if(temp_vol == void_vols[j]){
                  pop_voids[j] = pop_voids[j] + 1;
                  s2 = "Y";
                  break;
               }
                                                                   }
           }
          if(s2 == "N"){
             void_vols[count1] = void_list[i].return_void_vol();
             no_types_voids[count1] = void_list[i].return_no_bins();
             pop_voids[count1] = pop_voids[count1] + 1;
             count1 = count1 + 1;
          }
     }
    
    if (act_frame == 0){
        myfile1.open("voids.out");
    }else{
        myfile1.open("voids.out",ios::app);
    }
    for(i=0;i<count1;i++){
        //cout << pop_mols[i] << "  " << no_types_mols[i] << endl;
        myfile1 << act_frame << "   " << pop_voids[i] << "  x  " <<  void_vols[i] << endl;
    }
    myfile1 << "Total number of voids:           " << no_voids << endl;
    myfile1 << "Total number of emptyBins:         " << no_empty_bins << endl;
    double t_vol = 0.0;
    for(i=0;i<count1;i++){
        t_vol = void_vols[i]*pop_voids[i] + t_vol;
    }
    myfile1 << "Total void vol:   " << t_vol << endl;
    myfile1.close();

    //Following is for debugging purposes only
    myfile2.open("combined_empty_bins.xyz");
    myfile2 << no_empty_bins << endl;
    myfile2 << endl;
    for (i=0;i<count1;i++){
        std::string filename = std::to_string(no_types_voids[i]) +".xyz";
        myfile1.open(filename);
        myfile1 << pop_voids[i]*no_types_voids[i] << endl;
        myfile1 << endl;
        for (j=0;j<no_voids;j++){
             if (no_types_voids[i] == void_bin_list[j].size()){
                 for (k=0;k<void_bin_list[j].size();k++){
                      temp_bins = void_bin_list[j][k];
                      myfile1 << "C " << bin_list1[temp_bins].return_xc() << " " << bin_list1[temp_bins].return_yc() << " " << bin_list1[temp_bins].return_zc() << endl;
                      myfile2 << "C " << bin_list1[temp_bins].return_xc() << " " << bin_list1[temp_bins].return_yc() << " " << bin_list1[temp_bins].return_zc() << endl;
                 }
             }
        }
        myfile1.close();
    }
    myfile2.close();
   
    identify_void_edges(no_voids,void_list,bin_list1,grid_atom_count1);
    find_void_surface_atoms(no_voids,natoms1,grid_dr1,void_list,bin_list1,grid_atom_count1,grid_list1,at_list1,lx1,ly1,lz1,nx1,ny1,nz1);
    
     delete[] void_list;
}

//########################################################################################################
//Following function identities edges/edge bins of each void
void identify_void_edges(int no_voids,voids *void_list1,emptyBin *bin_list1,int ***grid_atom_count1){
     int i,j,k;
     int ibin,jbin,kbin;
     int ebin_no,no1,no2;
     int flag;
     int count,global_edge_count;
     ofstream myfile,myfile1;

     global_edge_count = 0;
     for (i=0;i<no_voids;i++){
          for (j=0;j<void_list1[i].vbin_list.size();j++){
               ebin_no = void_list1[i].vbin_list[j];
               no1 = bin_list1[ebin_no].num_neighbors;
               count = no1;
               /*for (k=0;k<no1;k++){
                    no2 = bin_list1[ebin_no].neigh_indexes[k]-1;
                    ibin = bin_list1[no2].return_xbin();
                    jbin = bin_list1[no2].return_ybin();
                    kbin = bin_list1[no2].return_zbin();
                    if(grid_atom_count1[ibin][jbin][kbin] == 0) count = count + 1;
               }*/
               if (count != 6){
                   void_list1[i].edge_list.push_back(ebin_no);
                   global_edge_count = global_edge_count + 1;
               }
          }
     }
    myfile.open("combined_void_edges.xyz");
    myfile << global_edge_count << endl;
    myfile << endl;
    for (i=0;i<no_voids;i++){
         std::string filename = std::to_string(void_list1[i].return_void_vol()) +"_" + std::to_string(i+1) + "_edge.xyz";
         myfile1.open(filename);
         no1 = void_list1[i].edge_list.size();
         myfile1 << no1 << endl;
         myfile1 << endl;
         for (j=0;j<void_list1[i].edge_list.size();j++){
              ebin_no = void_list1[i].edge_list[j];
              myfile << "N " << bin_list1[ebin_no].return_xc() << " " << bin_list1[ebin_no].return_yc() << " " << bin_list1[ebin_no].return_zc() << endl;
              myfile1 << "N " << bin_list1[ebin_no].return_xc() << " " << bin_list1[ebin_no].return_yc() << " " << bin_list1[ebin_no].return_zc() << endl;
         }
         myfile1.close();
    }
    myfile.close();
}

//#############################################################################################################
void find_void_surface_atoms(int no_voids, int natoms, double grid_dr1,voids *void_list1, emptyBin *bin_list1, int ***grid_atom_count1, int ****grid_list1, atom **at_list1, double **lx1, double **ly1, double **lz1, int nx1, int ny1, int nz1){
     int i,k,j,l,m,n;
     int ibin1,jbin1,kbin1;
     int ilo,ihi,jlo,jhi,klo,khi;
     int ibin,jbin,kbin;
     double xc,yc,zc;
     double xtemp,ytemp,ztemp;
     double x1,y1,z1,x2,y2,z2;
     double dx,dy,dz,dr,temp_dr;
     vector< vector <double> > at_dist_list;
     vector< double > temp_list;
     vector< double > temp_xlist;
     vector< double > temp_ylist;
     vector< double > temp_zlist;
     vector< int > temp_neigh_list;
     int edge_bin_count,edge_bin_no,ebin_no;
     int no1,no2,no3,at_id,temp1;
     int at_tag[natoms];
     int at_num_cutoff = 5;
     int total_edge_atoms = 0;
     int total_edge_faces = 0;
     int face_flag;
     string filename;
     ofstream myfile,myfile1;

     for (i=0;i<natoms;i++){
          at_tag[i] = 0;
     }

     myfile.open("voids_size.dat");
     for (i=0;i<no_voids;i++){
          temp_xlist.clear();
          temp_ylist.clear();
          temp_zlist.clear();
          edge_bin_count = void_list1[i].edge_list.size();
          for (j=0;j<edge_bin_count;j++){
               edge_bin_no = void_list1[i].edge_list[j]; //this number correponds to index in empty bin list
               xc  = bin_list1[edge_bin_no].return_xc();
               yc  = bin_list1[edge_bin_no].return_yc();
               zc  = bin_list1[edge_bin_no].return_zc();
               ibin1 = bin_list1[edge_bin_no].return_xbin();
               jbin1 = bin_list1[edge_bin_no].return_ybin();
               kbin1 = bin_list1[edge_bin_no].return_zbin();
               
               ilo = ibin1-1;
               ihi = ibin1+1;
               jlo = jbin1-1;
               jhi = jbin1+1;
               klo = kbin1-1;
               khi = kbin1+1;

               if (ilo < 0)     ilo = nx1-1;
               if (ihi > nx1-1) ihi = 0;

               if (jlo < 0)     jlo = ny1-1;
               if (jhi > ny1-1) jhi = 0;

               if (klo < 0)     klo = nz1-1;
               if (khi > nz1-1) khi = 0;

               temp_neigh_list.clear();
                 
               temp_neigh_list.push_back(ilo);
               temp_neigh_list.push_back(jbin1);
               temp_neigh_list.push_back(kbin1);
                
               temp_neigh_list.push_back(ihi);
               temp_neigh_list.push_back(jbin1);
               temp_neigh_list.push_back(kbin1);

               temp_neigh_list.push_back(ibin1);
               temp_neigh_list.push_back(jlo);
               temp_neigh_list.push_back(kbin1);

               temp_neigh_list.push_back(ibin1);
               temp_neigh_list.push_back(jhi);
               temp_neigh_list.push_back(kbin1);

               temp_neigh_list.push_back(ibin1);
               temp_neigh_list.push_back(jbin1);
               temp_neigh_list.push_back(klo);

               temp_neigh_list.push_back(ibin1);
               temp_neigh_list.push_back(jbin1);
               temp_neigh_list.push_back(khi);

               //no1 = bin_list1[edge_bin_no].num_neighbors;
               no1 = 6;
               for (k=0;k<no1;k++){
                    //no2 = bin_list1[edge_bin_no].neigh_indexes[k]-1;
                    //ibin = bin_list1[no2].return_xbin();
                    //jbin = bin_list1[no2].return_ybin();
                    //kbin = bin_list1[no2].return_zbin();
                    ibin = temp_neigh_list[k*3];
                    jbin = temp_neigh_list[k*3+1];
                    kbin = temp_neigh_list[k*3+2];
                    no3  = grid_atom_count1[ibin][jbin][kbin];
                    if (no3 != 0){
                        /*xtemp = grid_dr1*(ibin+1);
                        ytemp = grid_dr1*(jbin+1);
                        ztemp = grid_dr1*(kbin+1);*/
                        xtemp = xc;
                        ytemp = yc;
                        ztemp = zc;
                        if (k == 0) xtemp = xc - grid_dr1*0.5;
                        if (k == 1) xtemp = xc + grid_dr1*0.5;
                        if (k == 2) ytemp = yc - grid_dr1*0.5;
                        if (k == 3) ytemp = yc + grid_dr1*0.5;
                        if (k == 4) ztemp = zc - grid_dr1*0.5;
                        if (k == 5) ztemp = zc + grid_dr1*0.5;
                        face_flag = 0;
                        //check if the face is already in the list
                        for (l=0;l<void_list1[i].face_xc.size();l++){
                             if (xtemp == void_list1[i].face_xc[l] && ytemp == void_list1[i].face_yc[l] && ztemp == void_list1[i].face_zc[l]){ 
                                 face_flag = 1;
                                 break;
                             }
                        }
                        if (face_flag == 0){
                            void_list1[i].face_xc.push_back(xtemp);
                            void_list1[i].face_yc.push_back(ytemp);
                            void_list1[i].face_zc.push_back(ztemp);
                            total_edge_faces = total_edge_faces + 1;
                        }
                    }
                    at_dist_list.clear();
                    for (l=0;l<no3;l++){
                         temp_list.clear();
                         at_id = grid_list1[ibin][jbin][kbin][l];
                         temp_list.push_back(at_id);
                         xtemp = at_list1[0][at_id].return_xcord();
                         ytemp = at_list1[0][at_id].return_ycord();
                         ztemp = at_list1[0][at_id].return_zcord();
 
                         dx = xtemp-xc;
                         dy = ytemp-yc;
                         dz = ztemp-zc;

			 //check periodicity
                         //check for periodic images in x direction
                         if (k < 2){
                             if (dx > lx1[0][2]/2.0){
                                 dx = dx - lx1[0][2];
                             }
                             if(dx <= (-1.0)*(lx1[0][2]/2.0)){
                                dx = dx + lx1[0][2];
                             }
                             temp_list.push_back(dx);
                         }
                         if (1 < k < 4){
                             //check for periodic images in y direction
                             if (dy > ly1[0][2]/2.0){
                                 dy = dy - ly1[0][2];
                             }
                             if(dy <= (-1.0)*(ly1[0][2]/2.0)){
                                dy = dy + ly1[0][2];
                             }
                             temp_list.push_back(dy);
                         }
                         if (3 < k < 6){
                             //check for periodic images in z direction
                             if (dz > lz1[0][2]/2.0){
                                 dz = dz - lz1[0][2];
                             } 
                             if (dz <= (-1.0)*(lz1[0][2]/2.0)){
                                 dz = dz + lz1[0][2];
                             }
                             temp_list.push_back(dz);
                         }
                      
                         //dr = sqrt(dx*dx + dy*dy + dz*dz);
                         //temp_list.push_back(dr);
                         at_dist_list.push_back(temp_list);
                    }//loop for atoms in neighboring bin ends here
                    if (at_dist_list.size() > 0){
                        sort(at_dist_list.begin(),at_dist_list.end(),sortcol);
                        at_id = at_dist_list[0][0];
                        if (at_tag[at_id] == 0){
                            void_list1[i].edge_atom_list.push_back(at_id);
                            xtemp = at_list1[0][at_id].return_xcord();
                            ytemp = at_list1[0][at_id].return_ycord();
                            ztemp = at_list1[0][at_id].return_zcord();
                            temp_xlist.push_back(xtemp);
                            temp_ylist.push_back(ytemp);
                            temp_zlist.push_back(ztemp);
                            at_tag[at_id] = 1;
                            total_edge_atoms = total_edge_atoms + 1;
                        }
                    }
               }// k-loop ends here
          }
          //find approximate maximum lenghts in x,y and z directions using edge face coordinates
          void_list1[i].xlen = 0.0;
          void_list1[i].ylen = 0.0;
          void_list1[i].zlen = 0.0;
          for (j=0;j<void_list1[i].face_xc.size();j++){
               for (k=j+1;k<void_list1[i].face_xc.size();k++){
                    dx = void_list1[i].face_xc[k]-void_list1[i].face_xc[j];
                    dy = void_list1[i].face_yc[k]-void_list1[i].face_yc[j];
                    dz = void_list1[i].face_zc[k]-void_list1[i].face_zc[j];
                    if (dx > lx1[0][2]/2.0){
                        dx = dx - lx1[0][2];
                    } 
                    if (dx <= (-1.0)*(lx1[0][2]/2.0)){
                        dx = dx + lx1[0][2];
                    }
                    if (dy > ly1[0][2]/2.0){
                        dy = dy - ly1[0][2];
                    } 
                    if (dy <= (-1.0)*(ly1[0][2]/2.0)){
                        dy = dy + ly1[0][2];
                    }
                    if (dz > lz1[0][2]/2.0){
                        dz = dz - lz1[0][2];
                    } 
                    if (dz <= (-1.0)*(lz1[0][2]/2.0)){
                        dz = dz + lz1[0][2];
                    }
                    if (abs(dx) > void_list1[i].xlen) void_list1[i].xlen = abs(dx);
                    if (abs(dy) > void_list1[i].ylen) void_list1[i].ylen = abs(dy);
                    if (abs(dz) > void_list1[i].zlen) void_list1[i].zlen = abs(dz);
               }
          }
          myfile << i+1 << " " << void_list1[i].xlen << " " << void_list1[i].ylen << " " << void_list1[i].zlen << " " << void_list1[i].return_void_vol() << endl;
        //myfile << i+1 << " " << void_list1[i].xlen << " " << void_list1[i].ylen << " " << void_list1[i].zlen << " " << void_list1[i].return_void_vol() ;
        //myfile << " " << x1 << " " << x2 << " " << y1 << " " << y2 << endl;
     } //i-loop ends here
     myfile.close();

     cout << "Total number of surface atoms " << total_edge_atoms << endl;
     cout << "done identifying surface atoms" << endl;
      
     //write edge atoms files. One file contains all edge atoms of all voids
     //another file contains edge atoms of each void. 
     myfile.open("combined_void_edge_atoms.xyz");
     myfile << total_edge_atoms << endl;
     myfile << endl;
     for (i=0;i<no_voids;i++){
          std::string filename = std::to_string(void_list1[i].return_void_vol()) +"_" + std::to_string(i+1) +"_edge_atoms.xyz";
          myfile1.open(filename);
          no1 = void_list1[i].edge_atom_list.size();
          myfile1 << no1 << endl;
          myfile1 << endl;
          for (j=0;j<no1;j++){
               at_id = void_list1[i].edge_atom_list[j];
               myfile1 << at_list1[0][at_id].return_atomname() << " " << at_list1[0][at_id].return_xcord() << " " << at_list1[0][at_id].return_ycord() << " " << at_list1[0][at_id].return_zcord() << endl;
               myfile << at_list1[0][at_id].return_atomname() << " " << at_list1[0][at_id].return_xcord() << " " << at_list1[0][at_id].return_ycord() << " " << at_list1[0][at_id].return_zcord() << endl;
          }
          myfile1.close();
     }
     myfile.close();

     //write surface coordinates files. One file contains all surfaces of all voids
     //another file contains surfaces of each void. 
     myfile.open("combined_void_faces.xyz");
     myfile << total_edge_faces << endl;
     myfile << endl;
     for (i=0;i<no_voids;i++){
          std::string filename = std::to_string(void_list1[i].return_void_vol()) +"_" + std::to_string(i+1) + "_surface.xyz";
          myfile1.open(filename);
          no1 = void_list1[i].face_xc.size();
          myfile1 << no1 << endl;
          myfile1 << endl;
          for (j=0;j<no1;j++){
               myfile << "N " << void_list1[i].face_xc[j] << " " << void_list1[i].face_yc[j] << " " << void_list1[i].face_zc[j] << endl;
               myfile1 << "O " << void_list1[i].face_xc[j] << " " << void_list1[i].face_yc[j] << " " << void_list1[i].face_zc[j] << endl;
          }
          myfile1.close();
     }
     myfile.close();
     
}

bool sortcol( const vector<double>& v1,const vector<double>& v2){
     return v1[1] < v2[1];
}

void surface_atoms(int dirn, double grid_dr1, double xc, double yc, double zc,atom **at_list1, voids *void_list1,double **lx1, double **ly1, double **lz1){
   int i,j,k;
   int n1,n2;
   double num1,num2;
   double dr1,dr2;
   double small_dr = 1.0;
   

   //find bin extremities
   if (dirn < 2){
       num1 = yc - grid_dr1/2.0;
       num2 = yc + grid_dr1/2.0;
       if (num1 < ly1[0][0]) num1 = ly1[0][0];
       if (num2 > ly1[0][1]) num2 = ly1[0][1]; 
       if (std::fmod(num2-num1,small_dr) == 0.0){
           n1 = int((num2-num1)/small_dr);
       }else{
           n1 = int((num2-num1)/small_dr);
       }
   } else if (dirn < 4){
   }else{
   }
}
